import sys
import time
import keyboard

from player.player import Player
from ingame.utilities import get_text, iterate_text
from utilities import write_per_character, clear_screen
# sys.path.append(r'D:\PROGRAMMING\python\bani\Genshin-Impact-OOP-master\New Genshin Impact')

class Game():
    def __init__(self, player: Player, game_level: int=1):
        self.player = player
        self.game_level = game_level

        pass
    
    def start_game(self):
        write_per_character(get_text("continue_text", self.player)[0]['text'],
                        get_text("continue_text", self.player)[0]['delay'])

    
class Tutorial(Game):
    def __init__(self, player: Player, game_level: int = 1):
        self.is_loopable = True
        self.steps_of_tutorial = {
            1: self.tutorial_intro,
            2: self.get_hero_information
        }
        super().__init__(player, game_level)
    
    def intro(self):
        iterate_text("intro_text", self.player, 0, 0) #Shows player to the texts of introduction to the game 
        get_tutorial = ''
        while get_tutorial.lower() != 'y' and get_tutorial.lower() != 'n':
            get_tutorial = input(": ")
            if get_tutorial.lower() != 'y' and get_tutorial.lower() != 'n':
                clear_screen(0)
                print("Sorry, we haven't any option of that\n")
        clear_screen(0)
        return get_tutorial.lower()
        # if get_tutorial.lower() == 'y':
        #     self.tutorial()
        # pass
    def start_game(self):
        while self.is_loopable:
            get_tutorial = self.intro()
            if get_tutorial.lower() == 'y':
                for i in range(1, len(self.steps_of_tutorial)+1):
                    if i != len(self.steps_of_tutorial):
                        proceed_or_not = self.proceed_to_next_tutorial_func()
                    if proceed_or_not == 'y':
                        self.steps_of_tutorial[i]()
                    if proceed_or_not == 'n':
                        write_per_character("Alright, then.",0.05,1.5)
                        write_per_character(" Take care when you're about to entering the wild world of this fantasy for I no longer be with you.",0.05,1.5)
                # self.tutorial_intro()
            else:
                print(f"You chose not to take the tutorial... Enjoy the game!!!")
                time.sleep(2)
            self.is_loopable = False

    def tutorial_intro(self):
        iterate_text("tutorial_intro", self.player, 0, 5) #Shows player to the texts of tutorial of the game 
        for i, hero in enumerate(self.player.get_hero_owned()):
            write_per_character(f"{i+1}. {hero.get_name()}", 0.05, 1)
            # write_per_character(f"", 0, 0)
            print()
        iterate_text("tutorial_intro", self.player, 6,8) #texts of tutorial from index 3 up to index 5

    def proceed_to_next_tutorial_func(self):
        proceed_to_next_tutorial_text = f"""\nDo you want to proceed this step? [Y/N]: """
        proceed_to_next_tutorial = ''
        wrong_answer = True
        # Will loop if the player input neither 'y' nor 'n'
        while wrong_answer:
            write_per_character(proceed_to_next_tutorial_text, 0.05, 1)#texts of tutorial from index 3 up to index 5
            proceed_to_next_tutorial = input("")
            clear_screen(0)
            if proceed_to_next_tutorial.lower() != 'y' and proceed_to_next_tutorial.lower() != 'n':
                write_per_character("Sorry. ", 0.05, 1)
                write_per_character("Your answer doesn't seem quite right.", 0.05, 0)
                clear_screen(1)
            else:
                break
        
        return proceed_to_next_tutorial
    
    def get_hero_information(self):
        _continue = True
        iterate_text('get_hero_information_text', self.player, 0, 1)
        print()
        heroes_owned = self.player.get_hero_owned()
        while _continue:
            for i, hero in enumerate(heroes_owned):
                write_per_character(f"{i+1}. {hero.get_name()}", 0.05, 1.3)
                print()
            write_per_character("Choose Hero: ",0.05,0)
            try:
                choose_hero = input("")
                choose_hero = int(choose_hero)
                clear_screen(0)
                if choose_hero<1 or choose_hero > len(heroes_owned)+1:
                    write_per_character(f"You only have {len(heroes_owned)} hero(es) by the way...", 0.05, 1.5)    
                else: 
                    print(f"Hero Name: {heroes_owned[choose_hero-1].get_name()}")
                    print(f"Hero Level: {heroes_owned[choose_hero-1].get_level()}")
                    print(f"Hero Basic Attack Damage: {heroes_owned[choose_hero-1].get_basic_attack_damage()}")
                    print(f"Hero Basic Armor: {heroes_owned[choose_hero-1].get_armor()}")
                    print(f"Hero HP: {heroes_owned[choose_hero-1].get_hp()}")
                    print(f"Hero EXP: {heroes_owned[choose_hero-1].get_exp()}")
                    yes_no_question = ''
                    while yes_no_question.lower() != 'n' and yes_no_question.lower() != 'y':
                        write_per_character("Do you want to see the other one? [Y/N]: ", 0.05,0)
                        yes_no_question = input("")
                        if yes_no_question.lower() != 'n' and yes_no_question.lower() != 'y':
                            write_per_character("Sorry,",0.05, 1.5)
                            write_per_character(" your input doesn't seem quite right. Try again", 0.05, 1.5)
                            clear_screen(0)
                    if yes_no_question == 'n':
                        print("Good bye...")
                        time.sleep(2)
                        break
                    clear_screen(0)
            except ValueError:
                write_per_character("Sorry,",0.05, 1.5)
                write_per_character(" your input doesn't seem quite right. Try again", 0.05, 1.5)
                clear_screen(0)
        
    # def tutorial(self):
    #     self.tutorial_intro()
    #     proceed_or_not = self.proceed_to_next_tutorial_func()
    #     print(f"proceed_to_next_tutorial: {proceed_or_not}")
    #     pass